﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Maui.Storage;
using DailyFoodSetApp.Models;

namespace DailyFoodSetApp.Services;

public static class FoodService
{
    private static readonly HttpClient HttpClient = new() { Timeout = TimeSpan.FromSeconds(15) };
    private static List<FoodItem>? _cachedFoods;

    public static async Task<List<FoodItem>> GetAllFoodsAsync()
    {
        if (_cachedFoods != null && _cachedFoods.Any())
            return _cachedFoods;

        if (!MockApiConfig.IsConfigured || string.IsNullOrEmpty(MockApiConfig.EndpointUrl))
            return new List<FoodItem>();

        try
        {
            var remoteItems = await HttpClient.GetFromJsonAsync<List<FoodItem>>(MockApiConfig.EndpointUrl);
            if (remoteItems != null)
            {
                _cachedFoods = remoteItems;
            }
        }
        catch (Exception ex)
        {
            // 修复点：输出错误日志，不再静默失败
            System.Diagnostics.Debug.WriteLine($"[GetAllFoodsAsync] 获取数据失败: {ex.Message}");
            _cachedFoods = new List<FoodItem>();
        }

        return _cachedFoods ?? new List<FoodItem>();
    }

    public static async Task<bool> AddFoodToApiAsync(FoodItem newItem)
    {
        if (!MockApiConfig.IsConfigured) return false;

        try
        {
            var response = await HttpClient.PostAsJsonAsync(MockApiConfig.EndpointUrl, newItem);

            if (response.IsSuccessStatusCode)
            {
                var createdItem = await response.Content.ReadFromJsonAsync<FoodItem>();
                if (createdItem != null && _cachedFoods != null)
                {
                    _cachedFoods.Add(createdItem);
                }
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[AddFoodToApiAsync] 添加数据失败: {ex.Message}");
            return false;
        }
    }

    public static async Task<List<FoodItem>> SearchFoodsAsync(string query)
    {
        var allItems = await GetAllFoodsAsync();

        if (string.IsNullOrWhiteSpace(query))
            return allItems.OrderBy(f => f.Name).ToList();

        string normalized = query.Trim();
        return allItems.Where(f =>
            f.Name.Contains(normalized, StringComparison.OrdinalIgnoreCase) ||
            f.Category.Contains(normalized, StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => f.Name).ToList();
    }

    public static async Task<FoodItem> GetFoodByIdAsync(string id)
    {
        var allItems = await GetAllFoodsAsync();
        return allItems.FirstOrDefault(f => f.Id == id);
    }

    public static async Task<List<FoodItem>> GenerateMealPlanAsync(int targetCalories, string preferredSpiciness, string preferredSweetness)
    {
        var allItems = await GetAllFoodsAsync();
        var selectedPlan = new List<FoodItem>();
        var random = new Random();

        int breakfastCalLimit = (int)(targetCalories * 0.30) + 100;
        int lunchCalLimit = (int)(targetCalories * 0.35) + 150;
        int dinnerCalLimit = (int)(targetCalories * 0.30) + 150;
        int drinkCalLimit = (int)(targetCalories * 0.05) + 100;

        FoodItem FindMatch(string category, int maxCalories)
        {
            var candidates = allItems.Where(f =>
                f.Category.Equals(category, StringComparison.OrdinalIgnoreCase) &&
                f.Calories <= maxCalories).ToList();

            if (category.Equals("Drink", StringComparison.OrdinalIgnoreCase))
            {
                candidates = candidates.Where(f => f.Sweetness.Equals(preferredSweetness, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else
            {
                candidates = candidates.Where(f => f.Spiciness.Equals(preferredSpiciness, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (!candidates.Any())
            {
                return new FoodItem
                {
                    Name = "No match",
                    Category = category,
                    Calories = 0,
                    Spiciness = "-",
                    Sweetness = "-",
                    Description = "No items match your criteria."
                };
            }

            return candidates[random.Next(candidates.Count)];
        }

        selectedPlan.Add(FindMatch("Breakfast", breakfastCalLimit));
        selectedPlan.Add(FindMatch("Lunch", lunchCalLimit));
        selectedPlan.Add(FindMatch("Dinner", dinnerCalLimit));
        selectedPlan.Add(FindMatch("Drink", drinkCalLimit));

        return selectedPlan;
    }
    public static async Task<bool> DeleteFoodFromApiAsync(string id)
    {
        if (!MockApiConfig.IsConfigured || string.IsNullOrEmpty(id))
            return false;

        try
        {
            // Execute HTTP DELETE request to remote web server endpoint
            var response = await HttpClient.DeleteAsync($"{MockApiConfig.EndpointUrl.TrimEnd('/')}/{id}");

            if (response.IsSuccessStatusCode)
            {
                // Sync current state by removing the target record from runtime memory cache
                if (_cachedFoods != null)
                {
                    var target = _cachedFoods.FirstOrDefault(f => f.Id == id);
                    if (target != null)
                    {
                        _cachedFoods.Remove(target);
                    }
                }
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[Delete Dynamic Error] REST execution failed: {ex.Message}");
            return false;
        }
    }

    public static async Task<int> MigrateLocalDataToMockApiAsync(IProgress<double> progress)
    {
        if (!MockApiConfig.IsConfigured) return 0;

        try
        {
            var existingItems = await HttpClient.GetFromJsonAsync<List<FoodItem>>(MockApiConfig.EndpointUrl);
            if (existingItems != null && existingItems.Count > 0)
            {
                return -1; // API 中已有数据，避免重复迁移
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[Migrate检查已有数据] API为空或未就绪: {ex.Message}");
        }

        int successCount = 0;
        try
        {
            // 修复点：将文件名修正为正确的 "Food.json"
            using var stream = await FileSystem.OpenAppPackageFileAsync("Food.json");
            using var reader = new StreamReader(stream);
            var jsonContent = await reader.ReadToEndAsync();

            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var localItems = JsonSerializer.Deserialize<List<FoodItem>>(jsonContent, options);

            if (localItems != null && localItems.Any())
            {
                int totalItems = localItems.Count;

                for (int i = 0; i < totalItems; i++)
                {
                    var item = localItems[i];

                    // 修复点：将 Id 置空，由 MockAPI 在服务器端自动生成递增 ID，防止 POST 冲突
                    item.Id = null;

                    try
                    {
                        var response = await HttpClient.PostAsJsonAsync(MockApiConfig.EndpointUrl, item);
                        if (response.IsSuccessStatusCode)
                        {
                            successCount++;
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine($"[Migrate上传单条失败] 状态码: {response.StatusCode}");
                        }
                    }
                    catch (Exception innerEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"[Migrate网络异常]: {innerEx.Message}");
                    }

                    double currentProgress = (double)(i + 1) / totalItems;
                    progress?.Report(currentProgress);

                    await Task.Delay(200); // 防抖延迟，避免触发 MockAPI 的限流机制
                }
            }

            _cachedFoods = null; // 清空本地缓存，让 App 强制从线上拉取最新完整数据
        }
        catch (Exception ex)
        {
            // 修复点：捕获文件读取和整体异常
            System.Diagnostics.Debug.WriteLine($"[Migrate总体失败] 文件读取或序列化错误: {ex.Message}");
        }

        return successCount;
    }
}