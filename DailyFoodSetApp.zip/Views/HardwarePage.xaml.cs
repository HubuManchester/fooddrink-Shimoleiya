using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Devices;
using Microsoft.Maui.Devices.Sensors;
using Microsoft.Maui.Media;
using Microsoft.Maui.Graphics;

namespace DailyFoodSetApp.Views;

public class SocialPost
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    // Store as physical file path to prevent memory garbage collection in CollectionView
    public string ImagePath { get; set; }
    public string Description { get; set; }
    public string LocationInfo { get; set; }

    public bool HasImage => !string.IsNullOrEmpty(ImagePath);
    public bool HasLocation => !string.IsNullOrWhiteSpace(LocationInfo);
}

public partial class HardwarePage : ContentPage
{
    public ObservableCollection<SocialPost> FeedPosts { get; set; } = new();

    private bool _isFlashlightOn = false;
    private byte[] _currentImageBytes;
    private string _currentLocationText;

    public HardwarePage()
    {
        InitializeComponent();
        BindingContext = this;
    }

    // Centralized tactile feedback engine
    private void TriggerHapticFeedback()
    {
        try
        {
            HapticFeedback.Default.Perform(HapticFeedbackType.Click);
        }
        catch { /* Fallback silently if device lacks motor */ }
    }

    private async void OnTakePhotoClicked(object sender, EventArgs e)
    {
        TriggerHapticFeedback();
        try
        {
            // Hardware lock protection: 
            // Camera module cannot be opened if the flashlight service is locking it.
            if (_isFlashlightOn)
            {
                await Flashlight.Default.TurnOffAsync();
                _isFlashlightOn = false;
                FlashlightButton.Text = "Turn On Flashlight";
                FlashlightButton.BackgroundColor = Color.FromArgb("#512BD4");

                // Allow hardware kernel to release the lock
                await Task.Delay(300);
            }

            if (!MediaPicker.Default.IsCaptureSupported)
            {
                await DisplayAlert("Error", "Camera is not supported.", "OK");
                return;
            }

            var photoResult = await MediaPicker.Default.CapturePhotoAsync();
            if (photoResult != null)
            {
                await using var stream = await photoResult.OpenReadAsync();
                using var memoryStream = new MemoryStream();
                await stream.CopyToAsync(memoryStream);

                _currentImageBytes = memoryStream.ToArray();
                FoodPhoto.Source = ImageSource.FromStream(() => new MemoryStream(_currentImageBytes));
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Camera Error", ex.Message, "OK");
        }
    }

    private async void OnToggleFlashlightClicked(object sender, EventArgs e)
    {
        TriggerHapticFeedback();
        try
        {
            if (_isFlashlightOn)
            {
                await Flashlight.Default.TurnOffAsync();
                _isFlashlightOn = false;
                FlashlightButton.Text = "Turn On Flashlight";
                FlashlightButton.BackgroundColor = Color.FromArgb("#512BD4");
            }
            else
            {
                await Flashlight.Default.TurnOnAsync();
                _isFlashlightOn = true;
                FlashlightButton.Text = "Turn Off Flashlight";
                FlashlightButton.BackgroundColor = Color.FromArgb("#A95517");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"Flashlight fault: {ex.Message}", "OK");
        }
    }

    private async void OnGetLocationClicked(object sender, EventArgs e)
    {
        TriggerHapticFeedback();
        try
        {
            var parameters = new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10));
            var locationResult = await Geolocation.Default.GetLocationAsync(parameters);

            if (locationResult != null)
            {
                CoordinateLabel.Text = $"Lat: {locationResult.Latitude:F5}, Lon: {locationResult.Longitude:F5}";

                var placemarks = await Geocoding.Default.GetPlacemarksAsync(locationResult);
                var mark = placemarks?.FirstOrDefault();

                if (mark != null)
                {
                    _currentLocationText = $"{mark.Locality}, {mark.AdminArea}, {mark.CountryName}";
                }
                else
                {
                    _currentLocationText = $"Lat {locationResult.Latitude:F2}, Lon {locationResult.Longitude:F2}";
                }

                LocationLabel.Text = _currentLocationText;
                await DisplayAlert("Success", "Location acquired.", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Sensor Error", ex.Message, "OK");
        }
    }

    private void OnShareClicked(object sender, EventArgs e)
    {
        TriggerHapticFeedback();
        string textContent = PostDescriptionEditor.Text?.Trim();

        if (string.IsNullOrWhiteSpace(textContent) && _currentImageBytes == null)
        {
            DisplayAlert("Validation", "Please provide a description or a photo to publish.", "OK");
            return;
        }

        string savedImagePath = null;
        if (_currentImageBytes != null)
        {
            // Cache physical file to system directory to guarantee UI rendering
            savedImagePath = Path.Combine(FileSystem.CacheDirectory, $"post_{Guid.NewGuid():N}.jpg");
            File.WriteAllBytes(savedImagePath, _currentImageBytes);
        }

        var newPost = new SocialPost
        {
            Description = string.IsNullOrWhiteSpace(textContent) ? "Shared a moment." : textContent,
            LocationInfo = _currentLocationText,
            ImagePath = savedImagePath
        };

        FeedPosts.Insert(0, newPost);

        // Reset UI fields
        PostDescriptionEditor.Text = string.Empty;
        FoodPhoto.Source = null;
        _currentImageBytes = null;
        CoordinateLabel.Text = "Coordinates: Pending...";
        LocationLabel.Text = "Address: Pending...";
        _currentLocationText = null;
    }

    private void OnDeletePostClicked(object sender, EventArgs e)
    {
        TriggerHapticFeedback();
        if (sender is Button triggerButton && triggerButton.CommandParameter is string targetId)
        {
            var postToRemove = FeedPosts.FirstOrDefault(p => p.Id == targetId);
            if (postToRemove != null)
            {
                // Delete physical cached image to prevent storage leak
                if (!string.IsNullOrEmpty(postToRemove.ImagePath) && File.Exists(postToRemove.ImagePath))
                {
                    try { File.Delete(postToRemove.ImagePath); } catch { /* Ignore locked files */ }
                }
                FeedPosts.Remove(postToRemove);
            }
        }
    }
}