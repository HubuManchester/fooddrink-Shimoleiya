namespace DailyFoodSetApp.Views;
public partial class HardwarePage : ContentPage
{
    public HardwarePage()
    {
        InitializeComponent();
    }
    protected override void OnAppearing()
    {
        base.OnAppearing();
        DailyFoodSetApp.Services.AccessibilityService.ApplyFontScale(this);
    }
}