﻿using DailyFoodSetApp.Services;
using Microsoft.Maui.Devices.Sensors;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Controls;

namespace DailyFoodSetApp.Views;

public partial class MealGeneratorPage : ContentPage
{
    private bool _isShakeEventBusy = false;

    public MealGeneratorPage()
    {
        InitializeComponent();
        SpicinessPicker.SelectedIndex = 0;
        SweetnessPicker.SelectedIndex = 0;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        DailyFoodSetApp.Services.AccessibilityService.ApplyFontScale(this);

        if (Accelerometer.Default.IsSupported)
        {
            Accelerometer.Default.ShakeDetected += Accelerometer_ShakeDetected;
            if (!Accelerometer.Default.IsMonitoring)
            {
                Accelerometer.Default.Start(SensorSpeed.Game);
            }
        }
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        if (Accelerometer.Default.IsSupported && Accelerometer.Default.IsMonitoring)
        {
            Accelerometer.Default.Stop();
            Accelerometer.Default.ShakeDetected -= Accelerometer_ShakeDetected;
        }
    }

    private async void OnGenerateClicked(object sender, EventArgs e)
    {
        if (!int.TryParse(CaloriesEntry.Text, out int calories))
        {
            await DisplayAlert("Input Error", "Please enter a valid numeric value for calories.", "OK");
            return;
        }

        if (calories <= 0)
        {
            await DisplayAlert("Input Error", "Calories must be greater than zero.", "OK");
            return;
        }

        string spiciness = SpicinessPicker.SelectedItem?.ToString() ?? "Not Spicy";
        string sweetness = SweetnessPicker.SelectedItem?.ToString() ?? "Sugar Free";

        var plan = await FoodService.GenerateMealPlanAsync(calories, spiciness, sweetness);

        MealPlanCollection.ItemsSource = plan;
        ResultsContainer.IsVisible = true;

        await Task.Delay(100);
        DailyFoodSetApp.Services.AccessibilityService.ApplyFontScale(this);
    }

    private async void OnShakeButtonClicked(object sender, EventArgs e)
    {
        await DisplayAlert("Lucky Food", "Shake your device to get today's lucky food!", "OK");
    }

    private void Accelerometer_ShakeDetected(object sender, EventArgs e)
    {
        if (_isShakeEventBusy) return;
        _isShakeEventBusy = true;

        MainThread.BeginInvokeOnMainThread(async () =>
        {
            try
            {
                var allFoods = await FoodService.SearchFoodsAsync("");

                if (allFoods != null && allFoods.Any())
                {
                    var random = new Random();
                    var luckyFood = allFoods[random.Next(allFoods.Count)];

                    string message = $"Name: {luckyFood.Name}\n" +
                                     $"Category: {luckyFood.Category}\n" +
                                     $"Calories: {luckyFood.Calories} kcal\n" +
                                     $"Spiciness: {luckyFood.Spiciness}\n" +
                                     $"Sweetness: {luckyFood.Sweetness}\n\n" +
                                     $"Description: {luckyFood.Description}";

                    HapticFeedback.Default.Perform(HapticFeedbackType.Click);

                    await DisplayAlert("Today's Lucky Food", message, "Awesome!");
                }
            }
            finally
            {
                _isShakeEventBusy = false;
            }
        });
    }
}