using System;
using Microsoft.Maui.Controls;
using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Storage;
using DailyFoodSetApp.Services;
using Microsoft.Maui.Devices.Sensors;
using System.Threading.Tasks;

namespace DailyFoodSetApp.Views;

public partial class SettingsPage : ContentPage
{
    private const string ThemeIndexKey = "AppThemeIndex";

    public SettingsPage()
    {
        InitializeComponent();

        ThemePicker.SelectedIndex = Preferences.Default.Get(ThemeIndexKey, 0);
        FontSizeSlider.Value = AccessibilityService.CurrentFontScale;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        DailyFoodSetApp.Services.AccessibilityService.ApplyFontScale(this);
    }

    private void OnThemeChanged(object sender, EventArgs e)
    {
        if (Application.Current == null) return;

        int selectedIndex = ThemePicker.SelectedIndex;
        Preferences.Default.Set(ThemeIndexKey, selectedIndex);

        Application.Current.UserAppTheme = selectedIndex switch
        {
            1 => AppTheme.Light,
            2 => AppTheme.Dark,
            _ => AppTheme.Unspecified
        };

        SemanticScreenReader.Announce("Theme has been updated.");
    }

    private void OnFontSizeChanged(object sender, ValueChangedEventArgs e)
    {
        AccessibilityService.CurrentFontScale = e.NewValue;
        AccessibilityService.ApplyFontScale(this);
    }

    private void OnVibrateClicked(object sender, EventArgs e)
    {
        try
        {
            Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(500));
            HapticFeedback.Default.Perform(HapticFeedbackType.LongPress);
            SemanticScreenReader.Announce("Device vibrated.");
        }
        catch (FeatureNotSupportedException)
        {
            DisplayAlert("Error", "Vibration is not supported on this device.", "OK");
        }
        catch (Exception ex)
        {
            DisplayAlert("Error", $"An unexpected error occurred: {ex.Message}", "OK");
        }
    }

    private async void OnUploadDataClicked(object sender, EventArgs e)
    {
        UploadDataButton.IsEnabled = false;
        UploadProgressBar.IsVisible = true;
        UploadStatusLabel.IsVisible = true;
        UploadProgressBar.Progress = 0;
        UploadStatusLabel.Text = "Connecting to cloud...";

        var progressIndicator = new Progress<double>(value =>
        {
            UploadProgressBar.Progress = value;
            UploadStatusLabel.Text = $"Uploading: {(value * 100):F0}%";
        });

        int result = await FoodService.MigrateLocalDataToMockApiAsync(progressIndicator);

        if (result == -1)
        {
            UploadProgressBar.IsVisible = false;
            UploadStatusLabel.Text = "Database is already populated. No action needed.";
            await DisplayAlert("Cloud Sync", "Your MockAPI database already contains data. Duplication prevented.", "OK");
        }
        else if (result > 0)
        {
            UploadStatusLabel.Text = $"Successfully uploaded {result} items!";
            await DisplayAlert("Cloud Sync", $"Data migration complete. {result} items added to cloud.", "OK");
        }
        else
        {
            UploadProgressBar.IsVisible = false;
            UploadStatusLabel.Text = "Migration failed. Please check network.";
            await DisplayAlert("Cloud Sync", "Failed to upload data. Ensure MockApiConfig is correct and network is active.", "OK");
            UploadDataButton.IsEnabled = true;
        }
    }
}