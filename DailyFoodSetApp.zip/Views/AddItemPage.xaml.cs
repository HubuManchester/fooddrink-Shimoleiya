using DailyFoodSetApp.Models;
using DailyFoodSetApp.Services;

namespace DailyFoodSetApp.Views;

public partial class AddItemPage : ContentPage
{
    public AddItemPage()
    {
        InitializeComponent();
    }

    private async void OnSubmitButtonClicked(object sender, EventArgs e)
    {
        // Simple client side validation parameters assertion
        if (string.IsNullOrWhiteSpace(NameEntry.Text) || CategoryPicker.SelectedIndex < 0)
        {
            await DisplayAlert("Validation Error", "Name field and category picker must be specified.", "OK");
            return;
        }

        int.TryParse(CaloriesEntry.Text, out int parsedCalories);

        var customizedItem = new FoodItem
        {
            Id = Guid.NewGuid().ToString("N"), // Fallback tracking identifier
            Name = NameEntry.Text.Trim(),
            Calories = parsedCalories,
            Spiciness = SpicinessPicker.SelectedItem?.ToString() ?? "Not Spicy",
            Sweetness = SweetnessPicker.SelectedItem?.ToString() ?? "Sugar Free",
            Category = CategoryPicker.SelectedItem?.ToString() ?? "Breakfast",
            Description = string.IsNullOrWhiteSpace(DescriptionEditor.Text) ? "No content." : DescriptionEditor.Text.Trim()
        };

        // Post structured object instance payload data to remote mockapi gateway
        bool status = await FoodService.AddFoodToApiAsync(customizedItem);

        if (status)
        {
            await DisplayAlert("Operation Success", "Custom entry synchronized to cloud storage.", "OK");
            await Shell.Current.GoToAsync(".."); // Pop view hierarchy stack
        }
        else
        {
            await DisplayAlert("Network Failure", "Remote engine rejected the data payload.", "OK");
        }
    }
}