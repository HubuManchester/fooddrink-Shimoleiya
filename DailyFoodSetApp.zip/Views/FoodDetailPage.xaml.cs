using System;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Media;
using DailyFoodSetApp.Models;
using DailyFoodSetApp.Services;

namespace DailyFoodSetApp.Views;

[QueryProperty(nameof(TargetFoodId), "id")]
public partial class FoodDetailPage : ContentPage
{
    private FoodItem currentTargetItem;

    public string TargetFoodId
    {
        set => _ = FetchTargetNodeContextAsync(value);
    }

    public FoodDetailPage()
    {
        InitializeComponent();
    }

    private async Task FetchTargetNodeContextAsync(string id)
    {
        try
        {
            currentTargetItem = await FoodService.GetFoodByIdAsync(id);
            if (currentTargetItem != null)
            {
                NameDisplay.Text = currentTargetItem.Name;
                CategoryDisplay.Text = $"Category: {currentTargetItem.Category}";
                CaloriesDisplay.Text = currentTargetItem.CaloriesLabel;
                SpecsDisplay.Text = $"Spiciness: {currentTargetItem.Spiciness} | Sweetness: {currentTargetItem.Sweetness}";
                DescriptionDisplay.Text = string.IsNullOrWhiteSpace(currentTargetItem.Description)
                    ? "No description provided."
                    : currentTargetItem.Description;
            }
            else
            {
                NameDisplay.Text = "Item Not Found";
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[Load Error] Failed to retrieve item details: {ex.Message}");
        }
    }

    private async void OnNarrateSummaryClicked(object sender, EventArgs e)
    {
        if (currentTargetItem == null) return;

        string audioScript = $"{currentTargetItem.Name}, categorized under {currentTargetItem.Category}. Energy value is {currentTargetItem.CaloriesLabel}. Spiciness flavor is {currentTargetItem.Spiciness} and sweetness state is {currentTargetItem.Sweetness}.";

        try
        {
            // Safeguard speech engine rendering process safely
            await TextToSpeech.Default.SpeakAsync(audioScript, cancelToken: CancellationToken.None);
        }
        catch (Exception ttsException)
        {
            // Requirement Fix: Handled silently inside container to prevent application unexpected lifecycle termination
            System.Diagnostics.Debug.WriteLine($"[TTS Failure Suppressed Interceptor] Node skipped safely: {ttsException.Message}");
        }
    }

    private async void OnTerminateRecordClicked(object sender, EventArgs e)
    {
        if (currentTargetItem == null) return;

        bool approval = await DisplayAlert("Confirmation Required", "Purge this item irreversibly from MockAPI architecture?", "Yes, Delete", "No, Cancel");
        if (!approval) return;

        bool operationResult = await FoodService.DeleteFoodFromApiAsync(currentTargetItem.Id);

        if (operationResult)
        {
            await DisplayAlert("Cloud Purged", "The ledger index state was updated successfully.", "OK");
            await Shell.Current.GoToAsync(".."); // Return to lookup terminal grid feed page
        }
        else
        {
            await DisplayAlert("Sync Error", "Could not remove the specified entity from server context.", "OK");
        }
    }
}