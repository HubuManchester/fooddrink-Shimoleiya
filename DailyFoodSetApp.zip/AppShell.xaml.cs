﻿using DailyFoodSetApp.Views;

namespace DailyFoodSetApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Registered routing paths for navigation execution
        Routing.RegisterRoute(nameof(FoodDetailPage), typeof(FoodDetailPage));
        Routing.RegisterRoute(nameof(AddItemPage), typeof(AddItemPage));
    }
}